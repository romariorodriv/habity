package com.habity.habity_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HabityBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HabityBackendApplication.class, args);
	}

}
